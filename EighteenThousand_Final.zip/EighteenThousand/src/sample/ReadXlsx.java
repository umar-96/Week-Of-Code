package sample;

/**
 * Created by abdul on 12/4/16.
 */
        import org.apache.poi.ss.usermodel.Cell;
        import org.apache.poi.ss.usermodel.Row;
        import org.apache.poi.xssf.usermodel.XSSFCell;
        import org.apache.poi.xssf.usermodel.XSSFRow;
        import org.apache.poi.xssf.usermodel.XSSFSheet;
        import org.apache.poi.xssf.usermodel.XSSFWorkbook;

        import java.io.FileInputStream;
        import java.io.FileNotFoundException;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.io.InputStream;
        import java.util.ArrayList;
        import java.util.Iterator;

public class ReadXlsx {
    public static ArrayList<Data> Data=new ArrayList<>();
    public void parser(String fileName) {
        InputStream XlsxFileToRead = null;
        XSSFWorkbook workbook = null;
        try {
            XlsxFileToRead = new FileInputStream(fileName);

            //Getting the workbook instance for xlsx file
            workbook = new XSSFWorkbook(XlsxFileToRead);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //getting the first sheet from the workbook using sheet name.
        // We can also pass the index of the sheet which starts from '0'.
        XSSFSheet sheet = workbook.getSheetAt(0);
        XSSFRow row;
        XSSFCell cell;
        int j=0;

        //Iterating all the rows in the sheet
        Iterator rows = sheet.rowIterator();
        //ArrayList<Object> writedata =
        int a=0;
        while (rows.hasNext()) {
            if(a==0){
                a++;
                rows.next();
                continue;
            }
            row = (XSSFRow) rows.next();

            //Iterating all the cells of the current row
            Iterator cells = row.cellIterator();

            while (cells.hasNext()) {
                cell = (XSSFCell) cells.next();
                if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
                    //System.out.print(cell.getStringCellValue() + " ");
                    String s=cell.getStringCellValue();
                    //System.out.println(s);
                    String[] split=s.split("[.;:!?(){]");
                    for(int i=0;i<split.length;i++){
//						if(i==0){
//							System.out.println(split[i]+" ");
//						}
//						else
//							System.out.println(j+" "+split[i]+" ");
//
                        Data.add(new Data(j, split[i]));

                    }
                } else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
                    j=(int) cell.getNumericCellValue();
                    //System.out.print(j+" ");
                } else if (cell.getCellType() == XSSFCell.CELL_TYPE_BOOLEAN) {
                    System.out.print(cell.getBooleanCellValue() + " ");

                } else { // //Here if require, we can also add below methods to
                    // read the cell content
                    // XSSFCell.CELL_TYPE_BLANK
                    // XSSFCell.CELL_TYPE_FORMULA
                    // XSSFCell.CELL_TYPE_ERROR
                }
            }
            //System.out.println();
            try {workbook.getSheet("Sheet1");
                XlsxFileToRead.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void writeDataparser(String Filename){
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("sheet");

//        Object[][] bookData = {
//                {"Head First Java", "Kathy Serria", 79},
//                {"Effective Java", "Joshua Bloch", 36},
//                {"Clean Code", "Robert martin", 42},
//                {"Thinking in Java", "Bruce Eckel", 35},
//        };

        int rowCount = 0;

        for (int i=0;i<Data.size();i++) {
            XSSFRow row = sheet.createRow(rowCount++);

            int columnCount = 0;

            XSSFCell cell = row.createCell(columnCount++);
            cell.setCellValue((Data.get(i).id));
            cell = row.createCell(columnCount++);
            //cell = row.createCell(++columnCount);
            cell.setCellValue((Data.get(i).data));
//            for (int j=0;j<Data.size();j++) {
//
//            }

        }


        try (FileOutputStream outputStream = new FileOutputStream(Filename)) {
            workbook.write(outputStream);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }



}