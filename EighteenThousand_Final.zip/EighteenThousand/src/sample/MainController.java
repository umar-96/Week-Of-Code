package sample;

import com.jfoenix.controls.JFXTabPane;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tab;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

/**
 * Created by abdul on 12/3/16.
 */
public class MainController implements Initializable {

   // @FXML
    //BorderPane borderPane;

    @FXML
    JFXTabPane tabPane;

    static Stage stage;

    FirstInterfaceController firstInterfaceController = null;
    SecondInterface secondInterface = null;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../sample/FirstInterface.fxml"));

        try{
            loader.load();
            firstInterfaceController = loader.getController();
            tabPane.getTabs().add(firstInterfaceController.tab1);


            loader = new FXMLLoader(getClass().getResource("../sample/SecondInterface.fxml"));
            loader.load();
            secondInterface = loader.getController();
//            SecondInterface.
            tabPane.getTabs().add(secondInterface.tab2);

        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setStage(Stage stage){
        this.stage = stage;
        firstInterfaceController.setStage(stage);
        secondInterface.setStage(stage);
    }

}
