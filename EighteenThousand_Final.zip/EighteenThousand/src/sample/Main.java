package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        MainController mainController = null;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../sample/Tabs.fxml"));
        try{
            loader.load();
            mainController = loader.getController();
            //mainController.setStage(primaryStage);

        }catch (IOException e){
            e.printStackTrace();
        }

        primaryStage.setTitle("Eighteen Thousand");
        primaryStage.setScene(new Scene(mainController.tabPane, 700, 500));
        primaryStage.show();
        mainController.setStage(primaryStage);

    }

    @Override
    public void stop(){

        FirstInterfaceController fic = new FirstInterfaceController();

        task1 t1 = new task1();
        task1.Data = fic.data;

        t1.writeData1("t1.xlsx");

        task1comp tc = new task1comp();
        tc.Data = fic.data;
        tc.writeDatatask1("tc.xlsx");


        SecondInterface sic = new SecondInterface();

        task2 t2 = new task2();
        task2.Data = sic.data;

        t2.writeData2("t2.xlsx");

        task2comp t2c = new task2comp();
        t2c.Data = sic.data;

        t2c.writeDatatask2("tc2.xlsx");
    }



    public static void main(String[] args)
    {
//        FirstInterfaceController
        launch(args);
    }
}
