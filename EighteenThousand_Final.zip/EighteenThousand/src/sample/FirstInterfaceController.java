package sample;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXTextArea;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;

import java.net.URL;
import java.util.*;

import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class FirstInterfaceController implements Initializable{


    @FXML
    Tab tab1;

    @FXML
    JFXTextArea textArea;

    @FXML
    JFXCheckBox ch1;

    @FXML
    JFXCheckBox ch2;

    @FXML
    JFXCheckBox ch3;

    @FXML
    JFXCheckBox ch4;

    @FXML
    JFXCheckBox ch5;

    @FXML
    JFXCheckBox ch6;

    @FXML
    JFXCheckBox ch7;

    @FXML
    static JFXButton exitButton;

    static Stage stage = null;

    public JFXButton getExitButton(){
        return exitButton;
    }
    public static ArrayList<Data> data = new ArrayList<>();
    int[] randomNumbers;
    int index = 0;

    @FXML
    public void skipOnClicked(){

        data.get(index).skip++;
        String text = data.get(index).data;

        StringBuilder str = new StringBuilder(text);
        int idx = 70;

        while (idx < str.length())
        {
            str.insert(idx, "-\n");
            idx = idx + 70;
        }

        textArea.setText(str.toString());
        index++;

    }

    @FXML
    public void nextCommentOnClicked(){


        String text = data.get(index).data;

        StringBuilder str = new StringBuilder(text);
        int idx = 70;

        while (idx < str.length())
        {
            str.insert(idx, "-\n");
            idx = idx + 70;
        }

        textArea.setText(str.toString());

        if(ch1.isSelected()){
            data.get(index).opt1++;
        }

        if(ch2.isSelected()){
            data.get(index).opt2++;
        }

        if(ch3.isSelected()){
            data.get(index).opt3++;
        }

        if(ch4.isSelected()){
            data.get(index).opt4++;
        }

        if(ch5.isSelected()){
            data.get(index).opt5++;
        }

        if(ch6.isSelected()){
            data.get(index).opt6++;
        }

        if(ch7.isSelected()){
            data.get(index).opt7++;
        }

        index++;
        ch1.setSelected(false);
        ch2.setSelected(false);
        ch3.setSelected(false);
        ch4.setSelected(false);
        ch5.setSelected(false);
        ch6.setSelected(false);
        ch7.setSelected(false);
    }

    @FXML
    public void exitButtonOnClicked(){

        if(ch1.isSelected()){
            data.get(index).opt1++;
        }

        if(ch2.isSelected()){
            data.get(index).opt2++;
        }

        if(ch3.isSelected()){
            data.get(index).opt3++;
        }

        if(ch4.isSelected()){
            data.get(index).opt4++;
        }

        if(ch5.isSelected()){
            data.get(index).opt5++;
        }

        if(ch6.isSelected()){
            data.get(index).opt6++;
        }

        if(ch7.isSelected()){
            data.get(index).opt7++;
        }

        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        textArea.setEditable(false);
//        ReadXlsx readXlsx = new ReadXlsx();
//        readXlsx.parser("100 sample comments - interface tasks.xlsx");
//        readXlsx.writeDataparser("Parser.xlsx");
//
//        task1 t1 = new task1();
//        t1.readXLSXFile1("Parser.xlsx");
//        t1.writeData1("t1.xlsx");

        task1comp tc = new task1comp();
        tc.readXLSXFiletask1("t1.xlsx");
        tc.writeDatatask1("tc.xlsx");
        data = tc.Data;

        int size = data.size();
        randomNumbers = new int[size];

        Random random = new Random();

        int j = 1;
        for(int i = 0; i < size; i++) {


            int n = (random.nextInt(size - 1) + i + 0) % size;

            if (contains(randomNumbers, n)) {
                randomNumbers[i] = n;
            } else
                i--;
            if (i == size - 2) {
                randomNumbers[size - 1] = 0;
                break;
            }
        }

        nextCommentOnClicked();

    }

    public boolean contains(int[] numbers, int n){

        for(int i = 0; i < numbers.length; i++){

            if(numbers[i] == n)
                return false;
        }

        return true;
    }

    public void setStage(Stage stage){
        this.stage = stage;
        System.out.println("The stage is: " + this.stage);
    }
}
