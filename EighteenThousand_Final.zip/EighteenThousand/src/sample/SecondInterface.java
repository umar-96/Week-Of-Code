package sample;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;
import java.util.ResourceBundle;

import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;


public class SecondInterface implements Initializable{


    @FXML
    Tab tab2;

    @FXML
    JFXTextArea textArea;

    @FXML
    JFXTextField predicate;

    @FXML
    JFXComboBox<String> score;

    @FXML
    JFXComboBox<String> subject;

    @FXML
    JFXTextField othersubject;

    @FXML
    static JFXButton exitButton;

    JFXButton b = exitButton;
    @FXML
    static Stage stage = null;

    static ArrayList<Data> data = new ArrayList<>();
    int[] randomNumbers;
    int index = 0;
    int i = 0;

    @FXML
    public void skipOnClicked(){


        data.get(index).skip++;
        String text = data.get(index).data;

        StringBuilder str = new StringBuilder(text);
        int idx = 70;

        while (idx < str.length())
        {
            str.insert(idx, "-\n");
            idx = idx + 70;
        }

        textArea.setText(str.toString());
        index++;
    }

    @FXML
    public void nextCommentOnClicked(){

        String text = data.get(index).data;

        StringBuilder str = new StringBuilder(text);
        int idx = 70;

        while (idx < str.length())
        {
            str.insert(idx, "-\n");
            idx = idx + 70;
        }

        textArea.setText(str.toString());

        String score = ""; String subject = ""; String quality = "";

        if(this.score.getSelectionModel().getSelectedItem() != null)
        score = this.score.getSelectionModel().getSelectedItem();
        if(this.subject.getSelectionModel().getSelectedItem() != null)
        subject = this.subject.getSelectionModel().getSelectedItem();

        if(subject.equals("Others")) {
            subject = othersubject.getText();
            System.out.println(subject);
        }

        quality = predicate.getText();

        if(quality != "") {
            data.get(index).predicate = quality;
            predicate.setText("");
        }
        if(score != "") {
            data.get(index).score = Integer.parseInt(score);
            this.score.setValue("");
        }
        if(subject != "") {
            data.get(index).subject = subject;
            this.subject.setValue("");
            othersubject.setText("");
        }

        index++;
        i = 0;
    }

    @FXML
    public void exitButtonOnClicked(){

        String score = ""; String subject = ""; String quality = "";

        if(this.score.getSelectionModel().getSelectedItem() != null)
            score = this.score.getSelectionModel().getSelectedItem();
        if(this.subject.getSelectionModel().getSelectedItem() != null)
            subject = this.subject.getSelectionModel().getSelectedItem();

        if(subject.equals("Others")) {
            subject = othersubject.getText();
            System.out.println(subject);
        }

        quality = predicate.getText();

        if(quality != "") {
            data.get(index).predicate = quality;
            predicate.setText("");
        }
        if(score != "") {
            data.get(index).score = Integer.parseInt(score);
            this.score.setValue("");
        }
        if(subject != "") {
            data.get(index).subject = subject;
            this.subject.setValue("");
            othersubject.setText("");
        }

        stage.close();
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        textArea.setEditable(false);
        othersubject.setEditable(false);
        task2comp t2 = new task2comp();
        t2.readXLSXFiletask2("t2.xlsx");
        t2.writeDatatask2("tc2.xlsx");
        data = t2.Data;

        int size = data.size();
        randomNumbers = new int[size];

        Random random = new Random();

        int j = 1;
        for(int i = 0; i < size; i++) {


            int n = (random.nextInt(size - 1) + i + 0) % size;

            if (contains(randomNumbers, n)) {
                randomNumbers[i] = n;
            } else
                i--;
            if (i == size - 2) {
                randomNumbers[size - 1] = 0;
                break;
            }
        }


        subject.getItems().addAll("Course", "Instructor", "Others");
        score.getItems().addAll("1", "2", "3", "4", "5");

        subject.valueProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {

                if(newValue == "Others"){

                    othersubject.setEditable(true);
                }
                else
                    othersubject.setEditable(false);
            }
        });
        nextCommentOnClicked();
    }

    public boolean contains(int[] numbers, int n){

        for(int i = 0; i < numbers.length; i++){

            if(numbers[i] == n)
                return false;
        }

        return true;
    }

    public boolean confirmMessage(String message) {

        ButtonType ok = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(AlertType.WARNING, null, ok, cancel);

        alert.setTitle("Warning");
        alert.setHeaderText("Look, an Information Dialog");
        alert.setContentText(message);
        alert.showAndWait();

        if (alert.getResult() != null) {

            if (alert.getResult().getText().equalsIgnoreCase("ok")) {
                return true;
            }
        }
        return false;
    }

    public String othersClicked(){

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Other Subject");
        dialog.setHeaderText("Look, a Text Input Dialog");
        dialog.setContentText("Please enter a subject:");

        Optional<String> result = dialog.showAndWait();
        String s = null;
        if (result.isPresent()){
           s = result.get();
        }

        dialog.hide();
        return s;
    }

    public void setStage(Stage stage){
        this.stage = stage;
        System.out.println("The stage is: " + this.stage);
    }
}