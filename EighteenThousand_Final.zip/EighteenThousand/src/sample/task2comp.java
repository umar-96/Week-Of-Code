package sample;

/**
 * Created by abdul on 12/5/16.
 */

        import java.io.FileInputStream;
        import java.io.FileNotFoundException;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.io.InputStream;
        import java.util.ArrayList;
        import java.util.Iterator;

        import org.apache.poi.xssf.usermodel.XSSFCell;
        import org.apache.poi.xssf.usermodel.XSSFRow;
        import org.apache.poi.xssf.usermodel.XSSFSheet;
        import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class task2comp {
    public static ArrayList<Data> Data=new ArrayList<>();
    public void readXLSXFiletask2(String fileName) {
        InputStream XlsxFileToRead = null;
        XSSFWorkbook workbook = null;
        try {
            XlsxFileToRead = new FileInputStream(fileName);

            //Getting the workbook instance for xlsx file
            workbook = new XSSFWorkbook(XlsxFileToRead);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //getting the first sheet from the workbook using sheet name.
        // We can also pass the index of the sheet which starts from '0'.
        XSSFSheet sheet = workbook.getSheetAt(0);
        XSSFRow row;
        XSSFCell cell;
        String s=null; String subj=null; String pred=null;
        int j=0;
        int score=0;int skip=0;

        //Iterating all the rows in the sheet
        Iterator rows = sheet.rowIterator();
        int a=0;
        while (rows.hasNext()) {
            if(a==0){
                a++;
                rows.next();
                continue;
            }
            row = (XSSFRow) rows.next();

            //Iterating all the cells of the current row
            Iterator cells = row.cellIterator();
            int count=0;
            while (cells.hasNext()) {
                cell = (XSSFCell) cells.next();
                if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
                    if(count==2){
                        s=cell.getStringCellValue();
                    }
                    else if(count==3){
                        subj=cell.getStringCellValue();
                    }
                    else if(count==4){
                        pred=cell.getStringCellValue();
                    }

                } else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
                    if(count==1){
                        j=(int) cell.getNumericCellValue();
                    }
                    else if(count==5){
                        score=(int) cell.getNumericCellValue();
                    }
                    else if(count==6){
                        skip=(int) cell.getNumericCellValue();
                    }

                } else if (cell.getCellType() == XSSFCell.CELL_TYPE_BOOLEAN) {
                    System.out.print(cell.getBooleanCellValue() + " ");

                }
                count++;
            }
            Data.add(new Data(j,s,subj,pred,score,skip));
            //System.out.println();
            try {workbook.getSheet("Sheet1");
                XlsxFileToRead.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void writeDatatask2(String Filename){
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("task1");


        int rowCount = 0;
        int l=0;

        for (int i=-1;i<Data.size();i++) {
            XSSFRow row = sheet.createRow(rowCount++);

            int columnCount = 0;

            XSSFCell cell = row.createCell(columnCount++);
            if(l==0){
                cell.setCellValue("ID");
                cell = row.createCell(columnCount++);
                cell.setCellValue("ROW ID");
                cell = row.createCell(columnCount++);
                cell.setCellValue("COMMENT");
                cell = row.createCell(columnCount++);
                cell.setCellValue("SUBJECT");
                cell = row.createCell(columnCount++);
                cell.setCellValue("PREDICATE");
                cell = row.createCell(columnCount++);
                cell.setCellValue("Comment Score");
                cell = row.createCell(columnCount++);
                cell.setCellValue("Skip Count");
                l++;
                //i=0;
                continue;

            }
            cell.setCellValue(i+1);
            cell = row.createCell(columnCount++);
            cell.setCellValue((Data.get(i).id));
            cell = row.createCell(columnCount++);
            cell.setCellValue((Data.get(i).data));
            cell = row.createCell(columnCount++);
            cell.setCellValue((Data.get(i).subject));
            cell = row.createCell(columnCount++);
            cell.setCellValue((Data.get(i).predicate));
            cell = row.createCell(columnCount++);
            cell.setCellValue((Data.get(i).score));
            cell = row.createCell(columnCount++);
            cell.setCellValue((Data.get(i).skip));

        }


        try (FileOutputStream outputStream = new FileOutputStream(Filename)) {
            workbook.write(outputStream);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		task2comp task = new task2comp();
//		task.readXLSXFile("task2.xlsx");
//		for(int i=0;i<Data.size();i++){
//			System.out.println(Data.get(i).id  + " " + Data.get(i).data);
//
//		}
//		task.writeData("task2comp.xlsx");
//
//
//	}

}
