package sample;

/**
 * Created by abdul on 12/4/16.
 */

public class Data {
    int id;
    int opt1,opt2,opt3,opt4,opt5,opt6,opt7;
    int score,skip;
    String data,subject,predicate;

    public Data(int i, String data){
        id=i;
        this.data=data;
    }
    public Data(int i,String data, int o1,int o2,int o3,int o4,int o5,int o6,int o7,int skip){
        id=i;
        this.data=data;
        opt1=o1;
        opt2=o2;opt3=o3;opt4=o4;opt5=o5;opt6=o6;opt7=o7;
        this.skip=skip;
    }
    public Data(int i,String data,String subject,String pred,int count,int skip){
        id=i;
        this.data=data;
        this.subject=subject;
        predicate=pred;
        score=count;
        this.skip=skip;
    }
}